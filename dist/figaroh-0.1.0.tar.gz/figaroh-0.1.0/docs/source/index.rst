Welcome to figaroh's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules/identification
   modules/calibration 
   modules/measurements
   modules/tools
   modules/utils
   modules/visualisation

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
