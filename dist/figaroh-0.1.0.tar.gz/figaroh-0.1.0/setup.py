# Copyright [2021-2025] Thanh Nguyen
from setuptools import setup

setup()
